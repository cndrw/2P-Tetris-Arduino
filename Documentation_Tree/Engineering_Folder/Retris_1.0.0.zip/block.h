#ifndef BLOCK_H
#define BLOCK_H

#include "vector.h"
#include "constants.h"
#include "renderer.h"

class Block
{
  public:
    /**
     * @brief changes which specific block the object currently is
     * @param blockShape which Block it will be
     * @param name name of the new Block
     * @param startPosition where the Block will appear on the screen
     */
    Create(Vector blockShape[], uint8_t name, Vector startPosition)
    {
      memcpy(points, blockShape, sizeof(Vector) * BLOCK_LENGTH);
      blockName = name;
      position = startPosition;
      Renderer::IncludePicture(points, position, BLOCK_LENGTH);
    }

    /**
     * @brief rotates the block 90 degree clockwise
     */
    void Rotate()
    {
      switch(blockName)
      {
        case I:
          for (int i = 0; i < BLOCK_LENGTH; i++)
          {
            Vector temp = points[i];
            points[i].x = temp.y;
            points[i].y = temp.x;
          }
          break;

        case O:
          break;

        default:
          for (int i = 0; i < BLOCK_LENGTH; i++)
          {
            Vector temp = points[i];
            points[i].x = -temp.y;
            points[i].y = temp.x;
          }
          break;
      }
    }

    void MoveRight()
    {
      position.x++;
    }

    void MoveLeft()
    {
      position.x--;
    }

    void MoveDown()
    {
      // RemovePoints(points, position, BLOCK_LENGTH);
      position.y++;
      // IncludePicture(points, position, BLOCK_LENGTH);
    }

  public:
    Vector points[BLOCK_LENGTH];
    Vector position = {0,0};
    uint8_t blockName = 0;
};

#endif
