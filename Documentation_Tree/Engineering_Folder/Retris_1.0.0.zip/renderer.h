#ifndef RENDERER_H
#define RENDERER_H

#include "constants.h"
#include "vector.h"


namespace Renderer
{
  /**
   * @brief draws the current state of screen to the matrix 
   */
  void DrawScreen(int32_t matrix[])
  {
    for (int i = 0; i < ROWS; i++)
    {
      digitalWrite(CS, LOW);
      for (int j = 0; j < SIZE; j++)
      {
        uint8_t data = matrix[i + (j / 4) * 8] >> ((6 - ((j % 4) * 2)) * 4);

        // convert from MSB to LSB - source: https://wokwi.com/projects/318868939929027156
        data = ((data >> 1) & 0x55) | ((data << 1) & 0xAA);
        data = ((data >> 2) & 0x33) | ((data << 2) & 0xCC);
        data = (data >> 4) | (data << 4);

        // first define which row then send data
        SPI.transfer(i + 1);
        SPI.transfer(data);
        // shiftOut(DIN, CLK, MSBFIRST, i+1);
        // shiftOut(DIN, CLK, LSBFIRST, data);

      }
      digitalWrite(CS, HIGH);
    }
  }

  /**
   * @brief draws a block to the screen
   * @param points points that make up the block
   * @param anchorPoint coordinates where the block will be placed
   * @param length how many points the block has
   */
  void IncludePicture(Vector points[], Vector anchorPoint, int length)
  {
    for (int i = 0; i < length; i++)
    {
      int32_t& previousRow = screen[points[i].y + anchorPoint.y];
      previousRow |= ((int32_t)1 << (31 - (anchorPoint.x + points[i].x)));
    }  
  }

  /**
   * @brief removes a block from the screen
   * @param points points that make up the block
   * @param anchorPoint coordinates where the block will be removed
   * @param length how many points the block has
   */
  void RemovePoints(Vector points[], Vector anchorPoint, int length)
  {
    for (int i = 0; i < length; i++)
    {
      // int32_t& previousRow = screen[points[i].y + (anchorPoint.y - 1)];
      int32_t& previousRow = screen[points[i].y + anchorPoint.y];
      previousRow &= ~((int32_t)1 << (31 - (anchorPoint.x + points[i].x)));
    }
  }

  /**
   * @brief adds whole rows to the screen
   * @details can only add contigious rows 
   * @param rows collection of rows that will be added
   * @param insertAt at which row the insertion starts
   * @param length how many rows 
   */
  void IncludeRows(int32_t rows[], uint8_t insertAt, uint8_t length)
  {
    // for (uint8_t i = insertAt; i < insertAt + length; i++)
    // {
    //   screen[i] = rows[i - insertAt]; 
    // }
    memcpy(screen + insertAt, rows, sizeof(int32_t) * length);
  }

  /**
   * @brief removes all rows between to rows (inlcusiv)
   * @details can only remove contigious rows 
   * @param from start row
   * @param to end row
   */
  void ClearRows(uint8_t from, uint8_t to)
  {
    for (uint8_t i = from; i < to; i++)
    {
      screen[i] = 0;
    }
  }

  /**
   * @brief clears the whole screen
   */
  void ClearScreen()
  {
    for (int i = 0; i < 32; i++)
    {
      screen[i] = 0;
    }
  }
}

#endif
