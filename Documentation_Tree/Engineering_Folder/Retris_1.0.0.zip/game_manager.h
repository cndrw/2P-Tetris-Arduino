#ifndef GAME_MANAGER_H
#define GAME_MANAGER_H

// #include "system_process.h"
#include "retris_game.h"
#include "constants.h"
#include "audio.h"

/**
 * @class GameManager
 * @brief manages the gameplay of RetrisOS
 */
class GameManager : public Process
{
  public:
    GameManager()
    {
    }

    /**
     * @brief initializes the game session(s)
     * @param playerCount how many game instances will be started (max. 2)
     */
    void Init(uint8_t playerCount)
    {
      // redraw the screen in order to have an empty
      // one while the intro sequence is happening
      Renderer::DrawScreen(screen);

      // intro sequence
      HW::lcd.setCursor(0, 0);
      HW::lcd.print("Auf die Bloecke,");
      delay(1000);
      HW::lcd.setCursor(3, 1);
      HW::lcd.print("fertig, ");
      delay(1000);
      HW::lcd.print("LOS!");
      delay(100);
      HW::lcd.clear();


      switch (playerCount)
      {
        case GAME_OPT_1P:
        case GAME_OPT_2P:
          m_playerCount = playerCount;
          break;

        case GAME_OPT_LAST:
          // m_playerCount will be whatever it was last time
          break;
      }
      // Audio::StartSong();
      for (uint8_t i = 0; i < m_playerCount; i++)
      {
        games[i].Init();
      }
      Audio::PlayAudio(AUDIO_KOROBEINIKI);
    }

    /**
     * @brief updates each game instance and the music
     */
    void Update()
    {
      // Audio::PlaySong();
      uint8_t changeCondition = 0;
      for (uint8_t i = 0; i < m_playerCount; i++)
      {
        games[i].Update();
        // the finished game state has the value 3 so 3 * playerCount must be 3 (for one player)
        // or 6 (for two player)
        changeCondition += games[i].GetGameState();
      }
      if (changeCondition == GAME_STATE_FINISHED * m_playerCount)
      {
        Audio::PlayAudio(AUDIO_GAME_OVER);
        retris.ChangeProcess(SYS_PROCESS_MENUE, DEATH_MENUE);
      }
    }

    /**
     * @brief directs the pressed buttons to the game instances
     * @param pressedButton1 pressed button from controller 1
     * @param pressedButton2 pressed button from controller 2
     */
    void Input(uint8_t pressedButton1, uint8_t pressedButton2)
    {
      if (pressedButton1 == BUTTON_START)
      {
        // m_playerCount is identical to the makros GAME_OPT_xP
        retris.FreezeCurrentProcess(SYS_PROCESS_MENUE, PAUSE_MENUE);
        return;
      }

      games[0].ProcessInput(pressedButton1);
      if (m_playerCount == 2)
      {
        games[1].ProcessInput(pressedButton2);
      }
    }

    /**
     * @brief saves and freezes the game instances
     */
    void Freeze(bool freeze)
    {
      if (freeze)
      {
        SaveGameState();
      }
      else
      {
        LoadGameState();
        games[0].DrawGameField();
        if (m_playerCount == 2)
        {
          games[1].DrawGameField();
        }
      }
    }

  private:
    /**
     * @brief saves the current state of the playing field
     */
    void SaveGameState()
    {
      uint8_t row = 10 + 1;
      memcpy(m_savedFields, screen + row, sizeof(int32_t) * GAME_HEIGHT);
    }

    /**
     * @brief loads the saved game field state
     */
    void LoadGameState()
    {
      Renderer::IncludeRows(m_savedFields, 11, GAME_HEIGHT);
    }

  private:
    uint8_t m_playerCount = 1;

  private:
    TetrisGame games[2] = { TetrisGame({1, 10}), TetrisGame({19, 10}) };
    int32_t m_savedFields[GAME_HEIGHT] = {0};
};

#endif
