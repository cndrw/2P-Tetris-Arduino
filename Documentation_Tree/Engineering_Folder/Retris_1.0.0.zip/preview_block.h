#ifndef PREVIEW_BLOCK_H
#define PREVIEW_BLOCK_H

#include "vector.h"
#include "constants.h"

// This class is handling the preview section of the gameboard
class PreviewBlock
{
  public:
    /**
     * @brief updates the preview
     * @param name name of the block that will be previewed
     */
    void UpdatePreview(uint8_t name)
    {
      ClearPreview();

      memcpy(previewBlock, previewBlockShape[name], sizeof(Vector) * BLOCK_LENGTH);
      for (int i = 0; i < BLOCK_LENGTH; i++)
      {
        previewBlock[i] *= 2;
      }

      Vector position = borderPosition + positionTable[name];
      Renderer::IncludePicture(previewBlock, position, BLOCK_LENGTH);
      position.x++;
      Renderer::IncludePicture(previewBlock, position, BLOCK_LENGTH);
      position.y++;
      Renderer::IncludePicture(previewBlock, position, BLOCK_LENGTH);
      position.x--;
      Renderer::IncludePicture(previewBlock, position, BLOCK_LENGTH);
      position.y--;
    }

    /**
     * @brief draws the border of the preview
     */
    void DrawBorder()
    {
      int32_t horizontal = 0x00000FFF;
      int32_t vertical = 0x000000801;

      uint8_t offset = 32 - borderPosition.x - m_width;

      horizontal <<= offset;
      vertical <<= offset;

      screen[borderPosition.y] |= horizontal;
      screen[borderPosition.y + m_height -1] |= horizontal;

      for (int i = 0; i < m_height -1; i++)
      {
        screen[i + borderPosition.y + 1] |= vertical;
      }
    }

  private:
    /**
     * @brief clears the preview (not the borders)
     */
    void ClearPreview()
    {
      for (int i = 0; i < m_height - 2; i++)
      {
        int32_t previewMask = 0x000003FF;
        // +1 to prevent erasing the border
        screen[i + borderPosition.y + 1] &= ~(previewMask << (32 - m_width - borderPosition.x + 1));
      }
    }

  public:
    Vector borderPosition = {0, 0};
    Vector blockPosition = {0, 0};
  
  private:
    Vector previewBlock[BLOCK_LENGTH];
    const Vector positionTable[7] = { {4, 4}, {6, 4}, {5, 3}, {4, 4}, {6, 4}, {4, 3}, {6, 4} };
    uint8_t m_width = 12; // 10
    uint8_t m_height = 10; // 12
};

#endif
