#ifndef AUDIO_H
#define AUDIO_H

namespace Audio {
   /* 
  Tetris theme - (Korobeiniki) 
  Connect a piezo buzzer or speaker to pin 11 or select a new pin.
  More songs available at https://github.com/robsoncouto/arduino-songs                                            
                                              
                                              Robson Couto, 2019
*/

#define NOTE_B0  31
#define NOTE_C1  33
#define NOTE_CS1 35
#define NOTE_D1  37
#define NOTE_DS1 39
#define NOTE_E1  41
#define NOTE_F1  44
#define NOTE_FS1 46
#define NOTE_G1  49
#define NOTE_GS1 52
#define NOTE_A1  55
#define NOTE_AS1 58
#define NOTE_B1  62
#define NOTE_C2  65
#define NOTE_CS2 69
#define NOTE_D2  73
#define NOTE_DS2 78
#define NOTE_E2  82
#define NOTE_F2  87
#define NOTE_FS2 93
#define NOTE_G2  98
#define NOTE_GS2 104
#define NOTE_A2  110
#define NOTE_AS2 117
#define NOTE_B2  123
#define NOTE_C3  131
#define NOTE_CS3 139
#define NOTE_D3  147
#define NOTE_DS3 156
#define NOTE_E3  165
#define NOTE_F3  175
#define NOTE_FS3 185
#define NOTE_G3  196
#define NOTE_GS3 208
#define NOTE_A3  220
#define NOTE_AS3 233
#define NOTE_B3  247
#define NOTE_C4  262
#define NOTE_CS4 277
#define NOTE_D4  294
#define NOTE_DS4 311
#define NOTE_E4  330
#define NOTE_F4  349
#define NOTE_FS4 370
#define NOTE_G4  392
#define NOTE_GS4 415
#define NOTE_A4  440
#define NOTE_AS4 466
#define NOTE_B4  494
#define NOTE_C5  523
#define NOTE_CS5 554
#define NOTE_D5  587
#define NOTE_DS5 622
#define NOTE_E5  659
#define NOTE_F5  698
#define NOTE_FS5 740
#define NOTE_G5  784
#define NOTE_GS5 831
#define NOTE_A5  880
#define NOTE_AS5 932
#define NOTE_B5  988
#define NOTE_C6  1047
#define NOTE_CS6 1109
#define NOTE_D6  1175
#define NOTE_DS6 1245
#define NOTE_E6  1319
#define NOTE_F6  1397
#define NOTE_FS6 1480
#define NOTE_G6  1568
#define NOTE_GS6 1661
#define NOTE_A6  1760
#define NOTE_AS6 1865
#define NOTE_B6  1976
#define NOTE_C7  2093
#define NOTE_CS7 2217
#define NOTE_D7  2349
#define NOTE_DS7 2489
#define NOTE_E7  2637
#define NOTE_F7  2794
#define NOTE_FS7 2960
#define NOTE_G7  3136
#define NOTE_GS7 3322
#define NOTE_A7  3520
#define NOTE_AS7 3729
#define NOTE_B7  3951
#define NOTE_C8  4186
#define NOTE_CS8 4435
#define NOTE_D8  4699
#define NOTE_DS8 4978
#define REST 10

#define FCPU 16000000

#define AUDIO_KOROBEINIKI 0
#define AUDIO_BUTTON_SWITCH 1
#define AUDIO_BUTTON_PRESS 2
#define AUDIO_GAME_OVER 3

// change this to make the song slower or faster
constexpr uint8_t tempo = 144;
// this calculates the duration of a whole note in ms (60s/tempo)*4 beats
constexpr uint16_t wholeNote = (60000 * 4) / tempo;

static constexpr uint32_t Conv(int8_t noteValue)
{
  return noteValue == -4 ? (wholeNote / 4) * 1.5 : (wholeNote / noteValue);
}

// notes of the moledy followed by the duration.
// a 4 means a quarter note, 8 an eighteenth , 16 sixteenth, so on
// !!negative numbers are used to represent dotted notes,
// so -4 means a dotted quarter note, that is, a quarter plus an eighteenth!!
static volatile constexpr uint32_t korobeiniki[] = {

  //Based on the arrangement at https://www.flutetunes.com/tunes.php?id=192
  
  NOTE_E5,Conv(4),  NOTE_B4,Conv(8),  NOTE_C5,Conv(8),  NOTE_D5,Conv(4),  NOTE_C5,Conv(8),  NOTE_B4,Conv(8),
  NOTE_A4,Conv(4),  NOTE_A4,Conv(8),  NOTE_C5,Conv(8),  NOTE_E5,Conv(4),  NOTE_D5,Conv(8),  NOTE_C5,Conv(8),
  NOTE_B4,Conv(-4),  NOTE_C5,Conv(8),  NOTE_D5,Conv(4),  NOTE_E5,Conv(4),
  NOTE_C5,Conv(4),  NOTE_A4,Conv(4),  NOTE_A4,Conv(8),  NOTE_A4,Conv(4),  NOTE_B4,Conv(8),  NOTE_C5,Conv(8),

  NOTE_D5,Conv(-4),  NOTE_F5,Conv(8),  NOTE_A5,Conv(4),  NOTE_G5,Conv(8),  NOTE_F5,Conv(8),
  NOTE_E5,Conv(-4),  NOTE_C5,Conv(8),  NOTE_E5,Conv(4),  NOTE_D5,Conv(8),  NOTE_C5,Conv(8),
  NOTE_B4,Conv(4),  NOTE_B4,Conv(8),  NOTE_C5,Conv(8),  NOTE_D5,Conv(4),  NOTE_E5,Conv(4),
  NOTE_C5,Conv(4),  NOTE_A4,Conv(4),  NOTE_A4,Conv(4), REST,Conv(4),

  NOTE_E5,Conv(4),  NOTE_B4,Conv(8),  NOTE_C5,Conv(8),  NOTE_D5,Conv(4),  NOTE_C5,Conv(8),  NOTE_B4,Conv(8),
  NOTE_A4,Conv(4),  NOTE_A4,Conv(8),  NOTE_C5,Conv(8),  NOTE_E5,Conv(4),  NOTE_D5,Conv(8),  NOTE_C5,Conv(8),
  NOTE_B4,Conv(-4),  NOTE_C5,Conv(8),  NOTE_D5,Conv(4),  NOTE_E5,Conv(4),
  NOTE_C5,Conv(4),  NOTE_A4,Conv(4),  NOTE_A4,Conv(8),  NOTE_A4,Conv(4),  NOTE_B4,Conv(8),  NOTE_C5,Conv(8),

  NOTE_D5,Conv(-4),  NOTE_F5,Conv(8),  NOTE_A5,Conv(4),  NOTE_G5,Conv(8),  NOTE_F5,Conv(8),
  NOTE_E5,Conv(-4),  NOTE_C5,Conv(8),  NOTE_E5,Conv(4),  NOTE_D5,Conv(8),  NOTE_C5,Conv(8),
  NOTE_B4,Conv(4),  NOTE_B4,Conv(8),  NOTE_C5,Conv(8),  NOTE_D5,Conv(4),  NOTE_E5,Conv(4),
  NOTE_C5,Conv(4),  NOTE_A4,Conv(4),  NOTE_A4,Conv(4), REST,Conv(4),
  

  NOTE_E5,Conv(2),  NOTE_C5,Conv(2),
  NOTE_D5,Conv(2),   NOTE_B4,Conv(2),
  NOTE_C5,Conv(2),   NOTE_A4,Conv(2),
  NOTE_GS4,Conv(2),  NOTE_B4,Conv(4),  REST,Conv(8), 
  NOTE_E5,Conv(2),   NOTE_C5,Conv(2),
  NOTE_D5,Conv(2),   NOTE_B4,Conv(2),
  NOTE_C5,Conv(4),   NOTE_E5,Conv(4),  NOTE_A5,Conv(2),
  NOTE_GS5,Conv(2),

};

static volatile constexpr uint32_t buttonSwitch[] = { NOTE_G5, Conv(16) };
static volatile constexpr uint32_t buttonPress[] = { NOTE_D6, Conv(16) };
static volatile constexpr uint32_t gameOver[] = { REST, Conv(4), NOTE_G5, Conv(8), NOTE_DS5, Conv(8), NOTE_A4, Conv(2) };

volatile constexpr uint32_t* p_melodies[] = {
  korobeiniki,
  buttonSwitch,
  buttonPress,
  gameOver
};

volatile constexpr uint8_t songLengths[] = 
{
  sizeof(korobeiniki) / sizeof(korobeiniki[0]),
  sizeof(buttonSwitch) / sizeof(buttonSwitch[0]),
  sizeof(buttonPress) / sizeof(buttonPress[0]),
  sizeof(gameOver) / sizeof(gameOver[0]),
};


static volatile int noteDuration = 0;
static volatile uint8_t currentNote = 0;
static volatile uint8_t currentAudio = 0;
static volatile int iInterrupt = 0;
static volatile uint32_t top = 0;
static volatile uint32_t holdTime = 0; // how long the note should be played (in terms of timer ticks)
static volatile bool isLooping = false;

void StopAudio()
{
  TIMSK1 = 0;
  OCR1A = 0;
  holdTime = 0;
  iInterrupt = 0;
  noteDuration = 0;
  currentNote = 0;
  top = 0;
}

void PlayAudio(const uint8_t audio, const bool enableLooping = false)
{
  StopAudio(); // stop any audio which is still playing
  TIMSK1 |= (1 << OCIE1A);
  OCR1A = 1;
  currentAudio = audio;
  isLooping = enableLooping;
}

void Setup()
{
  TCCR1A = 0; // set entire TCCR1A register to 0
  TCCR1B = 0; // same for TCCR1B
  TCNT1  = 0; //initialize counter value to 0
  pinMode(11, OUTPUT);

  // Initialisiere den Timer1 im Fast PWM-Modus mit OCR1A als top
  TCCR1A |= (1 << WGM10) | (1 << WGM11) | (1 << COM1A0);
  TCCR1B = 0;
  TCCR1B |=  (1 << CS12) | (1 << WGM12) | (1 << WGM13) ;
}



ISR(TIMER1_COMPA_vect)
{
  if (currentNote > songLengths[currentAudio])
  {
    currentNote = 0;
    if (!isLooping)
    {
      StopAudio();
      return;
    }
  }

  if (iInterrupt > holdTime)
  {
    noteDuration = p_melodies[currentAudio][currentNote + 1];
  
    holdTime = (uint32_t)p_melodies[currentAudio][currentNote] * (uint32_t)noteDuration / 1000;
    // we only play the note for 90% of the duration, leaving 10% as a pause
    top = FCPU / ((int32_t)p_melodies[currentAudio][currentNote] * 256);

    OCR1A = top;
    // Serial.println();

    currentNote += 2;
    iInterrupt = 0;
  }
  else
  {
    iInterrupt++;
  }
}

// void PlaySong() 
// {
//   if (count < waitTime)
//   {
//     count++;
//     return;
//   }
//   startTime = micros();

//   count = 0;

//   // iterate over the notes of the melody. 
//   // Remember, the array is twice the number of notes (notes + durations)

//   // calculates the duration of each note
//   divider = melody[currentNote + 1];
//   if (divider > 0) {
//       // regular note, just proceed
//     noteDuration = (wholenote) / divider;
//   } else if (divider < 0) {
//       // dotted notes are represented with negative durations!!
//     noteDuration = (wholenote) / abs(divider);
//     noteDuration *= 1.5; // increases the duration in half for dotted notes
//   }

//     // we only play the note for 90% of the duration, leaving 10% as a pause
//   // noTone(buzzer);
//   tone(buzzer, melody[currentNote], noteDuration*0.9);

//     // Wait for the specief duration before playing the next note.
//   waitTime = noteDuration / 10;
//   // delay(noteDuration);
  
//     // stop the waveform generation before the next note.
//   currentNote += 2;
//   if (currentNote >= songLength)
//   {
//     Serial.println("----");
//     Serial.println(sum);
//     currentNote = 0;
//   }

//   delta = micros() - startTime;
//   sum += delta;
//   Serial.println(delta);
// }

}


/*
  TODO: noteDuration durch bit-shifting errechnen, da divider immer base 2 sind
*/

#endif
